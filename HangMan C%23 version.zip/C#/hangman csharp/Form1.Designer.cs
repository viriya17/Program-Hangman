﻿namespace hangman_csharp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Button15 = new System.Windows.Forms.Button();
            this.Button16 = new System.Windows.Forms.Button();
            this.Button17 = new System.Windows.Forms.Button();
            this.Button18 = new System.Windows.Forms.Button();
            this.Button19 = new System.Windows.Forms.Button();
            this.Button20 = new System.Windows.Forms.Button();
            this.Button21 = new System.Windows.Forms.Button();
            this.Button22 = new System.Windows.Forms.Button();
            this.Button23 = new System.Windows.Forms.Button();
            this.Button24 = new System.Windows.Forms.Button();
            this.Button25 = new System.Windows.Forms.Button();
            this.Button26 = new System.Windows.Forms.Button();
            this.Button27 = new System.Windows.Forms.Button();
            this.Button9 = new System.Windows.Forms.Button();
            this.Button10 = new System.Windows.Forms.Button();
            this.Button11 = new System.Windows.Forms.Button();
            this.Button12 = new System.Windows.Forms.Button();
            this.Button13 = new System.Windows.Forms.Button();
            this.Button14 = new System.Windows.Forms.Button();
            this.Button8 = new System.Windows.Forms.Button();
            this.Button7 = new System.Windows.Forms.Button();
            this.Button6 = new System.Windows.Forms.Button();
            this.Button5 = new System.Windows.Forms.Button();
            this.Button4 = new System.Windows.Forms.Button();
            this.Button3 = new System.Windows.Forms.Button();
            this.Button2 = new System.Windows.Forms.Button();
            this.Button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Button15
            // 
            this.Button15.Location = new System.Drawing.Point(412, 342);
            this.Button15.Name = "Button15";
            this.Button15.Size = new System.Drawing.Size(27, 23);
            this.Button15.TabIndex = 80;
            this.Button15.Text = "Z";
            this.Button15.UseVisualStyleBackColor = true;
            // 
            // Button16
            // 
            this.Button16.Location = new System.Drawing.Point(379, 342);
            this.Button16.Name = "Button16";
            this.Button16.Size = new System.Drawing.Size(27, 23);
            this.Button16.TabIndex = 79;
            this.Button16.Text = "Y";
            this.Button16.UseVisualStyleBackColor = true;
            // 
            // Button17
            // 
            this.Button17.Location = new System.Drawing.Point(346, 342);
            this.Button17.Name = "Button17";
            this.Button17.Size = new System.Drawing.Size(27, 23);
            this.Button17.TabIndex = 78;
            this.Button17.Text = "X";
            this.Button17.UseVisualStyleBackColor = true;
            // 
            // Button18
            // 
            this.Button18.Location = new System.Drawing.Point(313, 342);
            this.Button18.Name = "Button18";
            this.Button18.Size = new System.Drawing.Size(27, 23);
            this.Button18.TabIndex = 77;
            this.Button18.Text = "W";
            this.Button18.UseVisualStyleBackColor = true;
            // 
            // Button19
            // 
            this.Button19.Location = new System.Drawing.Point(280, 342);
            this.Button19.Name = "Button19";
            this.Button19.Size = new System.Drawing.Size(27, 23);
            this.Button19.TabIndex = 76;
            this.Button19.Text = "V";
            this.Button19.UseVisualStyleBackColor = true;
            // 
            // Button20
            // 
            this.Button20.Location = new System.Drawing.Point(247, 342);
            this.Button20.Name = "Button20";
            this.Button20.Size = new System.Drawing.Size(27, 23);
            this.Button20.TabIndex = 75;
            this.Button20.Text = "U";
            this.Button20.UseVisualStyleBackColor = true;
            // 
            // Button21
            // 
            this.Button21.Location = new System.Drawing.Point(212, 342);
            this.Button21.Name = "Button21";
            this.Button21.Size = new System.Drawing.Size(27, 23);
            this.Button21.TabIndex = 74;
            this.Button21.Text = "T";
            this.Button21.UseVisualStyleBackColor = true;
            // 
            // Button22
            // 
            this.Button22.Location = new System.Drawing.Point(179, 342);
            this.Button22.Name = "Button22";
            this.Button22.Size = new System.Drawing.Size(27, 23);
            this.Button22.TabIndex = 73;
            this.Button22.Text = "S";
            this.Button22.UseVisualStyleBackColor = true;
            // 
            // Button23
            // 
            this.Button23.Location = new System.Drawing.Point(146, 342);
            this.Button23.Name = "Button23";
            this.Button23.Size = new System.Drawing.Size(27, 23);
            this.Button23.TabIndex = 72;
            this.Button23.Text = "R";
            this.Button23.UseVisualStyleBackColor = true;
            // 
            // Button24
            // 
            this.Button24.Location = new System.Drawing.Point(113, 342);
            this.Button24.Name = "Button24";
            this.Button24.Size = new System.Drawing.Size(27, 23);
            this.Button24.TabIndex = 71;
            this.Button24.Text = "Q";
            this.Button24.UseVisualStyleBackColor = true;
            // 
            // Button25
            // 
            this.Button25.Location = new System.Drawing.Point(80, 342);
            this.Button25.Name = "Button25";
            this.Button25.Size = new System.Drawing.Size(27, 23);
            this.Button25.TabIndex = 70;
            this.Button25.Text = "P";
            this.Button25.UseVisualStyleBackColor = true;
            // 
            // Button26
            // 
            this.Button26.Location = new System.Drawing.Point(47, 342);
            this.Button26.Name = "Button26";
            this.Button26.Size = new System.Drawing.Size(27, 23);
            this.Button26.TabIndex = 69;
            this.Button26.Text = "O";
            this.Button26.UseVisualStyleBackColor = true;
            // 
            // Button27
            // 
            this.Button27.Location = new System.Drawing.Point(14, 342);
            this.Button27.Name = "Button27";
            this.Button27.Size = new System.Drawing.Size(27, 23);
            this.Button27.TabIndex = 68;
            this.Button27.Text = "N";
            this.Button27.UseVisualStyleBackColor = true;
            // 
            // Button9
            // 
            this.Button9.Location = new System.Drawing.Point(412, 313);
            this.Button9.Name = "Button9";
            this.Button9.Size = new System.Drawing.Size(27, 23);
            this.Button9.TabIndex = 67;
            this.Button9.Text = "M";
            this.Button9.UseVisualStyleBackColor = true;
            // 
            // Button10
            // 
            this.Button10.Location = new System.Drawing.Point(379, 313);
            this.Button10.Name = "Button10";
            this.Button10.Size = new System.Drawing.Size(27, 23);
            this.Button10.TabIndex = 66;
            this.Button10.Text = "L";
            this.Button10.UseVisualStyleBackColor = true;
            // 
            // Button11
            // 
            this.Button11.Location = new System.Drawing.Point(346, 313);
            this.Button11.Name = "Button11";
            this.Button11.Size = new System.Drawing.Size(27, 23);
            this.Button11.TabIndex = 65;
            this.Button11.Text = "K";
            this.Button11.UseVisualStyleBackColor = true;
            // 
            // Button12
            // 
            this.Button12.Location = new System.Drawing.Point(313, 313);
            this.Button12.Name = "Button12";
            this.Button12.Size = new System.Drawing.Size(27, 23);
            this.Button12.TabIndex = 64;
            this.Button12.Text = "J";
            this.Button12.UseVisualStyleBackColor = true;
            // 
            // Button13
            // 
            this.Button13.Location = new System.Drawing.Point(280, 313);
            this.Button13.Name = "Button13";
            this.Button13.Size = new System.Drawing.Size(27, 23);
            this.Button13.TabIndex = 63;
            this.Button13.Text = "I";
            this.Button13.UseVisualStyleBackColor = true;
            // 
            // Button14
            // 
            this.Button14.Location = new System.Drawing.Point(247, 313);
            this.Button14.Name = "Button14";
            this.Button14.Size = new System.Drawing.Size(27, 23);
            this.Button14.TabIndex = 62;
            this.Button14.Text = "H";
            this.Button14.UseVisualStyleBackColor = true;
            // 
            // Button8
            // 
            this.Button8.Location = new System.Drawing.Point(212, 313);
            this.Button8.Name = "Button8";
            this.Button8.Size = new System.Drawing.Size(27, 23);
            this.Button8.TabIndex = 61;
            this.Button8.Text = "G";
            this.Button8.UseVisualStyleBackColor = true;
            // 
            // Button7
            // 
            this.Button7.Location = new System.Drawing.Point(179, 313);
            this.Button7.Name = "Button7";
            this.Button7.Size = new System.Drawing.Size(27, 23);
            this.Button7.TabIndex = 60;
            this.Button7.Text = "F";
            this.Button7.UseVisualStyleBackColor = true;
            // 
            // Button6
            // 
            this.Button6.Location = new System.Drawing.Point(146, 313);
            this.Button6.Name = "Button6";
            this.Button6.Size = new System.Drawing.Size(27, 23);
            this.Button6.TabIndex = 59;
            this.Button6.Text = "E";
            this.Button6.UseVisualStyleBackColor = true;
            // 
            // Button5
            // 
            this.Button5.Location = new System.Drawing.Point(113, 313);
            this.Button5.Name = "Button5";
            this.Button5.Size = new System.Drawing.Size(27, 23);
            this.Button5.TabIndex = 58;
            this.Button5.Text = "D";
            this.Button5.UseVisualStyleBackColor = true;
            // 
            // Button4
            // 
            this.Button4.Location = new System.Drawing.Point(80, 313);
            this.Button4.Name = "Button4";
            this.Button4.Size = new System.Drawing.Size(27, 23);
            this.Button4.TabIndex = 57;
            this.Button4.Text = "C";
            this.Button4.UseVisualStyleBackColor = true;
            // 
            // Button3
            // 
            this.Button3.Location = new System.Drawing.Point(47, 313);
            this.Button3.Name = "Button3";
            this.Button3.Size = new System.Drawing.Size(27, 23);
            this.Button3.TabIndex = 56;
            this.Button3.Text = "B";
            this.Button3.UseVisualStyleBackColor = true;
            // 
            // Button2
            // 
            this.Button2.Location = new System.Drawing.Point(14, 313);
            this.Button2.Name = "Button2";
            this.Button2.Size = new System.Drawing.Size(27, 23);
            this.Button2.TabIndex = 55;
            this.Button2.Text = "A";
            this.Button2.UseVisualStyleBackColor = true;
            // 
            // Button1
            // 
            this.Button1.Location = new System.Drawing.Point(455, 313);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(75, 23);
            this.Button1.TabIndex = 54;
            this.Button1.Text = "New";
            this.Button1.UseVisualStyleBackColor = true;
            this.Button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(546, 381);
            this.Controls.Add(this.Button15);
            this.Controls.Add(this.Button16);
            this.Controls.Add(this.Button17);
            this.Controls.Add(this.Button18);
            this.Controls.Add(this.Button19);
            this.Controls.Add(this.Button20);
            this.Controls.Add(this.Button21);
            this.Controls.Add(this.Button22);
            this.Controls.Add(this.Button23);
            this.Controls.Add(this.Button24);
            this.Controls.Add(this.Button25);
            this.Controls.Add(this.Button26);
            this.Controls.Add(this.Button27);
            this.Controls.Add(this.Button9);
            this.Controls.Add(this.Button10);
            this.Controls.Add(this.Button11);
            this.Controls.Add(this.Button12);
            this.Controls.Add(this.Button13);
            this.Controls.Add(this.Button14);
            this.Controls.Add(this.Button8);
            this.Controls.Add(this.Button7);
            this.Controls.Add(this.Button6);
            this.Controls.Add(this.Button5);
            this.Controls.Add(this.Button4);
            this.Controls.Add(this.Button3);
            this.Controls.Add(this.Button2);
            this.Controls.Add(this.Button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "HangMan";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Button Button15;
        internal System.Windows.Forms.Button Button16;
        internal System.Windows.Forms.Button Button17;
        internal System.Windows.Forms.Button Button18;
        internal System.Windows.Forms.Button Button19;
        internal System.Windows.Forms.Button Button20;
        internal System.Windows.Forms.Button Button21;
        internal System.Windows.Forms.Button Button22;
        internal System.Windows.Forms.Button Button23;
        internal System.Windows.Forms.Button Button24;
        internal System.Windows.Forms.Button Button25;
        internal System.Windows.Forms.Button Button26;
        internal System.Windows.Forms.Button Button27;
        internal System.Windows.Forms.Button Button9;
        internal System.Windows.Forms.Button Button10;
        internal System.Windows.Forms.Button Button11;
        internal System.Windows.Forms.Button Button12;
        internal System.Windows.Forms.Button Button13;
        internal System.Windows.Forms.Button Button14;
        internal System.Windows.Forms.Button Button8;
        internal System.Windows.Forms.Button Button7;
        internal System.Windows.Forms.Button Button6;
        internal System.Windows.Forms.Button Button5;
        internal System.Windows.Forms.Button Button4;
        internal System.Windows.Forms.Button Button3;
        internal System.Windows.Forms.Button Button2;
        internal System.Windows.Forms.Button Button1;
    }
}

